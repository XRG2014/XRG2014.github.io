<h1 align="center"><b> Welcome to The <i>XRG2014</i> Webserver/Website &#128187; </b></h1>

__________________________________________________________________________________________________________________________________________________

<a href="https://raw.githubusercontent.com/XRG2014/XRG2014.github.io/main/assets/images/Favicon.png?raw=true"><p align="center">
  <img width="500" height="500" src="https://raw.githubusercontent.com/XRG2014/XRG2014.github.io/main/assets/images/Favicon.png?raw=true">
</p></a>

__________________________________________________________________________________________________________________________________________________

### **_ABOUT:_**

[<img src="https://raw.githubusercontent.com/XRG2014/XRG2014.github.io/main/assets/images/IMG_2516.jpeg?raw=true" width="100px" height="100px"/>](https://github.com/)

<img src="https://raw.githubusercontent.com/XRG2014/XRG2014.github.io/main/assets/images/IMG_2517.jpeg?raw=true" width="100px" height="100px"/>

> This Website Was Made Using **_Github_**
> _________________________________________________________________________________________________________________

[<img src="https://raw.githubusercontent.com/pages-themes/hacker/master/thumbnail.png" width="130px" height="100px"/>](https://github.com/pages-themes/hacker/tree/master/)

<img src="https://raw.githubusercontent.com/XRG2014/XRG2014.github.io/main/assets/images/IMG_2517.jpeg?raw=true" width="100px" height="100px"/>

> This Website Was Made Using **_pages-themes/hacker_** Theme
> _________________________________________________________________________________________________________________

> This Website Was Made By **_XRG2014_** (And some credit for my friend)
> _________________________________________________________________________________________________________________

My **_Youtube channels_**:

[My main Youtube channel](https://www.youtube.com/channel/UCNLYKQvHtclDzZUokODLZAg)

[![Main Youtube channel trailer](https://img.youtube.com/vi/HYiFt8Y14PE/0.jpg)](https://www.youtube.com/watch?v=HYiFt8Y14PE)

[My tech Youtube channel I work on with my friend](https://www.youtube.com/channel/UCNdGvV63d2nWbBYMVATwLNg)

[My other tech Youtube channel I work on with my friend](https://www.youtube.com/channel/UCXJSQpw3BvrsnT6ZYvgCCGg)

<b><i>Nebulatic </i></b>( An operating system my friend and I are working on, and it'll be based off of windows 10 ):

[<img src="https://raw.githubusercontent.com/XRG2014/XRG2014.github.io/main/assets/images/IMG_2477.jpeg?raw=true" width="100"/>](https://github.com/NebulaticOfficial/Nebulatic-OS)

Find me on <b><i>Scratch</i></b>:

[Scratch](https://scratch.mit.edu/users/XRG2014/)

Friend me on <b><i>Minecraft</i></b>:

	XRG2014

__________________________________________________________________________________________________________________________________________________
